﻿using System;

internal class WebApplication
{
    internal static object CreateBuilder(string[] args)
    {
        throw new NotImplementedException();
    }
}