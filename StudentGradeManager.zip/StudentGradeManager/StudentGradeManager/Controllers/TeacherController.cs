﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using StudentGradeManager.Models;
using StudentGradeManager.Store;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentGradeManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class TeacherController : ControllerBase
    {
        private readonly string _connectionString;
        private string _jwtKey;
        public TeacherController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _jwtKey = configuration["Jwt:Secretkey"];
        }

        // GET: api/Teacher/Teachers/{id}
        [HttpGet("Teachers/{id}")]
        public ActionResult<Teacher> GetTeacher(int id)
        {
            Teacher teacher = null;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT TeacherID,Role, Name, Email, Password, Rank FROM Teachers WHERE TeacherID = @TeacherID", connection);
                command.Parameters.AddWithValue("@TeacherID", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        teacher =(new Teacher
                        {
                            TeacherID = !reader.IsDBNull(reader.GetOrdinal("TeacherID")) ? reader.GetInt32(reader.GetOrdinal("TeacherID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            Rank = reader["Rank"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });
                    }
                }
            }

            if (teacher == null)
            {
                return NotFound("Teacher not found.");
            }

            return Ok(teacher);
        }

        // GET: api/Teacher/{teacherId}
        [HttpGet("{teacherId}")]
        public ActionResult<object> GetAssignedCourses(int teacherId)
        {
            var assignedCourses = new List<object>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    SELECT ca.CourseID, c.CourseName, ca.Semester, s.StudentID, s.Name
                    FROM CourseAssignments ca
                    INNER JOIN Courses c ON ca.CourseID = c.CourseID
                    INNER JOIN Students s ON FIND_IN_SET(s.StudentID, ca.StudentID) > 0
                    WHERE ca.TeacherID = @TeacherID", connection);
                command.Parameters.AddWithValue("@TeacherID", teacherId);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        assignedCourses.Add(new
                        {
                            CourseID = reader.GetInt32("CourseID"),
                            CourseName = reader.GetString("CourseName"),
                            Semester = reader.GetString("Semester"),
                            StudentID = reader.GetInt32("StudentID"),
                            StudentName = reader.GetString("Name")
                        });
                    }
                }
            }

            if (!assignedCourses.Any())
            {
                return NotFound("No course assignments found for this teacher.");
            }

            return Ok(assignedCourses);
        }

        private string GetExistingTeacherPassword(int teacherId, MySqlConnection connection)
        {
            var command = new MySqlCommand("SELECT Password FROM Teachers WHERE TeacherID = @TeacherID", connection);
            command.Parameters.AddWithValue("@TeacherID", teacherId);

            var password = command.ExecuteScalar()?.ToString();
            if (password == null)
            {
                throw new Exception("Teacher not found or password is missing.");
            }

            return password;
        }


        // PUT: api/Teacher/{id}
        [HttpPut("{id}")]
        public ActionResult UpdateTeacher(int id, [FromBody] Teacher updatedTeacher)
        {
            if (updatedTeacher == null || updatedTeacher.TeacherID != id)
            {
                return BadRequest("Invalid teacher data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Hash the password before updating it
                string hashedPassword = string.IsNullOrWhiteSpace(updatedTeacher.Password)
                    ? GetExistingTeacherPassword(id, connection) // Retrieve existing password if not provided
                    : BCrypt.Net.BCrypt.HashPassword(updatedTeacher.Password);

                var command = new MySqlCommand(@"
            UPDATE Teachers
            SET Name = @Name, Email = @Email, Password = @Password, Rank = @Rank
            WHERE TeacherID = @TeacherID", connection);

                command.Parameters.AddWithValue("@TeacherID", id);
                command.Parameters.AddWithValue("@Name", updatedTeacher.Name);
                command.Parameters.AddWithValue("@Email", updatedTeacher.Email);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@Rank", updatedTeacher.Rank);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("Teacher not found.");
                }
            }

            return NoContent();
        }


        // POST: api/Teacher/{teacherId}/InputGrades
        [HttpPost("{teacherId}/InputGrades")]
        public ActionResult InputGrades(int teacherId, [FromBody] UpdateGradeRequest inputGradesRequest)
        {
            if (inputGradesRequest == null || inputGradesRequest.MidtermGrade < 0 || inputGradesRequest.MidtermGrade > 100 ||
                inputGradesRequest.FinalGrade < 0 || inputGradesRequest.FinalGrade > 100)
            {
                return BadRequest("Invalid grade data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Calculate the average within the SQL query using MidtermGrade and FinalGrade
                var command = new MySqlCommand(@"
            INSERT INTO grades (TeacherID, StudentID, CourseID, Semester, MidtermGrade, FinalGrade, FinalAverage)
            VALUES (@TeacherID, @StudentID, @CourseID, @Semester, @MidtermGrade, @FinalGrade, 
                    (@MidtermGrade + @FinalGrade) / 2)  
            ON DUPLICATE KEY UPDATE
                MidtermGrade = @MidtermGrade, 
                FinalGrade = @FinalGrade,
                FinalAverage = (@MidtermGrade + @FinalGrade) / 2  
        ", connection);

                command.Parameters.AddWithValue("@TeacherID", inputGradesRequest.TeacherID);
                command.Parameters.AddWithValue("@StudentID", inputGradesRequest.StudentID);
                command.Parameters.AddWithValue("@CourseID", inputGradesRequest.CourseID);
                command.Parameters.AddWithValue("@Semester", inputGradesRequest.Semester);
                command.Parameters.AddWithValue("@MidtermGrade", inputGradesRequest.MidtermGrade);
                command.Parameters.AddWithValue("@FinalGrade", inputGradesRequest.FinalGrade);

                command.ExecuteNonQuery();
            }

            return Ok(new { Message = "Grades inputted or updated successfully." });
        }


        // PUT: api/Teacher/{teacherId}/UpdateGrades
        [HttpPut("{teacherId}/UpdateGrades")]
        public ActionResult UpdateGrades(int teacherId, [FromBody] UpdateGradeRequest inputGradesRequest)
        {
            // Validate if the inputGradesRequest is null or if the grades are out of range
            if (inputGradesRequest == null || inputGradesRequest.MidtermGrade < 0 || inputGradesRequest.MidtermGrade > 100 ||
                inputGradesRequest.FinalGrade < 0 || inputGradesRequest.FinalGrade > 100)
            {
                return BadRequest("Invalid grade data. Grades must be between 0 and 100.");
            }

            // Validate if the teacherId matches the teacher's ID in the request
            if (teacherId != inputGradesRequest.TeacherID)
            {
                return Unauthorized("Teacher is not authorized to update grades for this student.");
            }

            // Open the database connection and execute the update query
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // SQL query for updating grades and calculating the Average
                var command = new MySqlCommand(@"
            UPDATE grades
            SET 
                MidtermGrade = @MidtermGrade, 
                FinalGrade = @FinalGrade, 
                FinalAverage = (@MidtermGrade + @FinalGrade) / 2  
            WHERE TeacherID = @TeacherID 
            AND StudentID = @StudentID 
            AND CourseID = @CourseID 
            AND Semester = @Semester", connection);

                // Add parameters to the SQL command
                command.Parameters.AddWithValue("@TeacherID", inputGradesRequest.TeacherID);
                command.Parameters.AddWithValue("@StudentID", inputGradesRequest.StudentID);
                command.Parameters.AddWithValue("@CourseID", inputGradesRequest.CourseID);
                command.Parameters.AddWithValue("@Semester", inputGradesRequest.Semester);
                command.Parameters.AddWithValue("@MidtermGrade", inputGradesRequest.MidtermGrade);
                command.Parameters.AddWithValue("@FinalGrade", inputGradesRequest.FinalGrade);

                // Execute the update command
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("No grades found for the given student, course, and semester to update.");
                }
            }

            // Return a success response
            return Ok(new { Message = "Grades updated successfully." });
        }



        [HttpGet("{teacherId}/PerformanceReport")]
        public ActionResult<object> GetPerformanceReport(int teacherId, [FromQuery] string semester)
        {
            var performanceReports = new List<object>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                var command = new MySqlCommand(@"
            SELECT DISTINCT s.StudentID, s.Name, sg.CourseID, c.CourseName,
       sg.MidtermGrade, sg.FinalGrade, sg.FinalAverage
FROM grades sg
INNER JOIN courses c ON sg.CourseID = c.CourseID
INNER JOIN students s ON sg.StudentID = s.StudentID
INNER JOIN courseAssignments ca ON ca.CourseID = sg.CourseID AND ca.TeacherID = @TeacherID
WHERE sg.Semester = @Semester
AND sg.GradeID IN (
    SELECT MAX(GradeID)
    FROM grades
    WHERE StudentID = sg.StudentID
    AND CourseID = sg.CourseID
    AND Semester = sg.Semester
    GROUP BY StudentID, CourseID, Semester
);

            ", connection);

                command.Parameters.AddWithValue("@TeacherID", teacherId);
                command.Parameters.AddWithValue("@Semester", semester);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        performanceReports.Add(new
                        {
                            StudentID = reader.GetInt32("StudentID"),
                            StudentName = reader.GetString("Name"),
                            CourseID = reader.GetInt32("CourseID"),
                            CourseName = reader.GetString("CourseName"),
                            MidtermGrade = reader.IsDBNull(reader.GetOrdinal("MidtermGrade")) ? 0.0 : reader.GetDouble("MidtermGrade"),
                            FinalGrade = reader.IsDBNull(reader.GetOrdinal("FinalGrade")) ? 0.0 : reader.GetDouble("FinalGrade"),
                            FinalAverage = reader.IsDBNull(reader.GetOrdinal("FinalAverage")) ? 0.0 : reader.GetDouble("FinalAverage") // Handle null average
                        });

                    }
                }
            }

            if (!performanceReports.Any())
            {
                return NotFound("No performance data found for the specified teacher and semester.");
            }

            return Ok(performanceReports);
        }

    }
}
