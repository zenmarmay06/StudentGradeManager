﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using BCrypt.Net;
using StudentGradeManager.Models;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;

namespace StudentGradeManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class LoginController : ControllerBase
    {
        private readonly string _connectionString;
        private string _jwtKey;

        public LoginController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _jwtKey = configuration["Jwt:Secretkey"];

        }

        #region Register Endpoints

        // Admin registration 
        [HttpPost("register/admin")]
        public ActionResult RegisterAdmin([FromBody] Admin admin)
        {
            if (string.IsNullOrEmpty(admin.Name) || string.IsNullOrEmpty(admin.Email) || string.IsNullOrEmpty(admin.Password))
                return BadRequest("Missing required fields.");

            if (string.IsNullOrEmpty(admin.Position)) // Ensure Position is not null or empty
                return BadRequest("Position is required for admin.");

            // Check if admin already exists
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT COUNT(*) FROM Admins WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", admin.Email);

                var existingAdminCount = Convert.ToInt32(command.ExecuteScalar());
                if (existingAdminCount > 0)
                {
                    return BadRequest("Admin with this email already exists.");
                }

                var hashedPassword = BCrypt.Net.BCrypt.HashPassword(admin.Password);
                var insertQuery = "INSERT INTO Admins (Role,Name, Email, Password, Position) VALUES (@Role,@Name, @Email, @Password, @Position)";
                var insertCommand = new MySqlCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@Role", admin.Role);
                insertCommand.Parameters.AddWithValue("@Name", admin.Name);
                insertCommand.Parameters.AddWithValue("@Email", admin.Email);
                insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                insertCommand.Parameters.AddWithValue("@Position", admin.Position);

                insertCommand.ExecuteNonQuery();

                // Get the auto-generated AdminID
                var lastInsertedIdQuery = "SELECT LAST_INSERT_ID()";
                var lastInsertedIdCommand = new MySqlCommand(lastInsertedIdQuery, connection);
                var adminId = Convert.ToInt32(lastInsertedIdCommand.ExecuteScalar());

                return Ok(new { Message = "Admin account created successfully.", AdminID = adminId });
            }
        }

        // Teacher registration
        [HttpPost("register/teacher")]
        public ActionResult RegisterTeacher([FromBody] Teacher teacher)
        {
            if (string.IsNullOrEmpty(teacher.Name) || string.IsNullOrEmpty(teacher.Email) || string.IsNullOrEmpty(teacher.Password))
                return BadRequest("Missing required fields.");

            // Check if teacher already exists
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT COUNT(*) FROM Teachers WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", teacher.Email);

                var existingTeacherCount = Convert.ToInt32(command.ExecuteScalar());
                if (existingTeacherCount > 0)
                {
                    return BadRequest("Teacher with this email already exists.");
                }

                var hashedPassword = BCrypt.Net.BCrypt.HashPassword(teacher.Password);
                var insertQuery = "INSERT INTO Teachers (Role,Name, Email, Password, Rank) VALUES (@Role,@Name, @Email, @Password, @Rank)";
                var insertCommand = new MySqlCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@Role", teacher.Role);
                insertCommand.Parameters.AddWithValue("@Name", teacher.Name);
                insertCommand.Parameters.AddWithValue("@Email", teacher.Email);
                insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                insertCommand.Parameters.AddWithValue("@Rank", teacher.Rank);

                insertCommand.ExecuteNonQuery();

                // Get the auto-generated TeacherID
                var lastInsertedIdQuery = "SELECT LAST_INSERT_ID()";
                var lastInsertedIdCommand = new MySqlCommand(lastInsertedIdQuery, connection);
                var teacherId = Convert.ToInt32(lastInsertedIdCommand.ExecuteScalar());

                return Ok(new { Message = "Teacher account created successfully.", TeacherID = teacherId });
            }
        }

        // Student registration
        [HttpPost("register/student")]
        public ActionResult RegisterStudent([FromBody] Student student)
        {
            if (string.IsNullOrEmpty(student.Name) || string.IsNullOrEmpty(student.Email) || string.IsNullOrEmpty(student.Password))
                return BadRequest("Missing required fields.");

            if (string.IsNullOrEmpty(student.YearSection))
                return BadRequest("YearSection is required for students.");

            // Check if student already exists
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT COUNT(*) FROM Students WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", student.Email);

                var existingStudentCount = Convert.ToInt32(command.ExecuteScalar());
                if (existingStudentCount > 0)
                {
                    return BadRequest("Student with this email already exists.");
                }

                var hashedPassword = BCrypt.Net.BCrypt.HashPassword(student.Password);
                var insertQuery = "INSERT INTO Students (Role,Name, Email, Password, YearSection) VALUES (@Role,@Name, @Email, @Password, @YearSection)";
                var insertCommand = new MySqlCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@Role", student.Role);
                insertCommand.Parameters.AddWithValue("@Name", student.Name);
                insertCommand.Parameters.AddWithValue("@Email", student.Email);
                insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                insertCommand.Parameters.AddWithValue("@YearSection", student.YearSection);

                insertCommand.ExecuteNonQuery();

                // Get the auto-generated StudentID
                var lastInsertedIdQuery = "SELECT LAST_INSERT_ID()";
                var lastInsertedIdCommand = new MySqlCommand(lastInsertedIdQuery, connection);
                var studentId = Convert.ToInt32(lastInsertedIdCommand.ExecuteScalar());

                return Ok(new { Message = "Student account created successfully.", StudentID = studentId });
            }
        }

        #endregion


        #region Login Endpoints

        // Admin login
        [HttpPost("login/admin")]
        public ActionResult LoginAdmin([FromBody] Login model)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Admins WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", model.Email);
                var reader = command.ExecuteReader();

                if (!reader.Read() || !BCrypt.Net.BCrypt.Verify(model.Password, reader["Password"].ToString()))
                    return Unauthorized("Invalid email or password.");

                var token = GenerateJwtToken(reader["Email"].ToString(), "Admin", model.Platform);
                return Ok(new { Token = token, TokenExpiration = DateTime.UtcNow.AddHours(1), Message = "Admin logged in successfully." });
            }
        }

        // Teacher login
        [HttpPost("login/teacher")]
        public ActionResult LoginTeacher([FromBody] Login model)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Teachers WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", model.Email);
                var reader = command.ExecuteReader();

                if (!reader.Read() || !BCrypt.Net.BCrypt.Verify(model.Password, reader["Password"].ToString()))
                    return Unauthorized("Invalid email or password.");

                var token = GenerateJwtToken(reader["Email"].ToString(), "Teacher", model.Platform);
                return Ok(new { Token = token, TokenExpiration = DateTime.UtcNow.AddHours(1), Message = "Teacher logged in successfully." });
            }
        }

        // Student login
        [HttpPost("login/student")]
           // Adding the [Authorize] attribute here
        public ActionResult LoginStudent([FromBody] Login model)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Students WHERE Email = @Email";
                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", model.Email);
                var reader = command.ExecuteReader();

                if (!reader.Read() || !BCrypt.Net.BCrypt.Verify(model.Password, reader["Password"].ToString()))
                    return Unauthorized("Invalid email or password.");

                var token = GenerateJwtToken(reader["Email"].ToString(), "Student", model.Platform);
                return Ok(new { Token = token, TokenExpiration = DateTime.UtcNow.AddHours(1), Message = "Student logged in successfully." });
            }
        }

        #endregion

        // Method to generate JWT token
        private string GenerateJwtToken(string email, string role, string platform)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jwtKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Email, email),
                    new Claim(ClaimTypes.Role, role),
                    new Claim("Platform", platform)
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
