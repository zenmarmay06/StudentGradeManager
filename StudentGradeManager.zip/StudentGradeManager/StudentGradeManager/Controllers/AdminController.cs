﻿using Microsoft.AspNetCore.Mvc;
using StudentGradeManager.Models;
using StudentGradeManager.Store;
using StudentGradeManager.Utility;
using System.Collections.Generic;
using System.Linq;
using System;
using Microsoft.AspNetCore.Authorization;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace StudentGradeManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class AdminController : ControllerBase
    {
        private readonly string _connectionString;
        private string _jwtKey;

        public static List<CourseAssignment> CourseAssignments { get; internal set; }

        public AdminController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _jwtKey = configuration["Jwt:Secretkey"];
        }

        [HttpGet("Admins")]
        //[Authorize(Roles = "Admin")]
        public ActionResult<IEnumerable<Admin>> GetAdmins()
        {
            var admins = new List<Admin>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT AdminID,Role, Name, Email, Password, Position FROM Admins", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        admins.Add(new Admin
                        {
                            AdminID = !reader.IsDBNull(reader.GetOrdinal("AdminID")) ? reader.GetInt32(reader.GetOrdinal("AdminID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            Position = reader["Position"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });

                    }
                }
            }

            if (admins.Count == 0)
            {
                return NotFound("No admins found.");
            }

            return Ok(admins);
        }

        [HttpGet("Teachers")]
        public ActionResult<IEnumerable<Teacher>> GetTeachers()
        {
            var teachers = new List<Teacher>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT TeacherID,Role, Name, Email, Password, Rank FROM Teachers", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        teachers.Add(new Teacher
                        {
                            TeacherID = !reader.IsDBNull(reader.GetOrdinal("TeacherID")) ? reader.GetInt32(reader.GetOrdinal("TeacherID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            Rank = reader["Rank"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });

                    }
                }
            }

            if (teachers.Count == 0)
            {
                return NotFound("No teachers found.");
            }

            return Ok(teachers);
        }

        [HttpGet("Students")]
        public ActionResult<IEnumerable<Student>> GetStudents()
        {
            var students = new List<Student>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT StudentID,Role, Name, Email, Password, YearSection FROM Students", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        students.Add(new Student
                        {
                            StudentID = !reader.IsDBNull(reader.GetOrdinal("StudentID")) ? reader.GetInt32(reader.GetOrdinal("StudentID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            YearSection = reader["YearSection"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });

                    }
                }
            }

            if (students.Count == 0)
            {
                return NotFound("No students found.");
            }

            return Ok(students);
        }
        // GET: api/AdminController/Admins/{id}
        [HttpGet("Admins/{id}")]
        public ActionResult<Admin> GetAdmin(int id)
        {
            Admin admin = null;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT AdminID,Role, Name, Email,Password, Position FROM Admins WHERE AdminID = @AdminID", connection);
                command.Parameters.AddWithValue("@AdminID", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        admin=(new Admin
                        {
                            AdminID = !reader.IsDBNull(reader.GetOrdinal("AdminID")) ? reader.GetInt32(reader.GetOrdinal("AdminID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            Position = reader["Position"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });
                    }
                }
            }

            if (admin == null)
            {
                return NotFound("Admin not found.");
            }

            return Ok(admin);
        }

        [HttpGet("Teachers/{id}")]
        public ActionResult<Teacher> GetTeacher(int id)
        {
            Teacher teacher = null;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT TeacherID,Role, Name, Email,Password, Rank FROM Teachers WHERE TeacherID = @TeacherID", connection);
                command.Parameters.AddWithValue("@TeacherID", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        teacher = (new Teacher
                        {
                            TeacherID = !reader.IsDBNull(reader.GetOrdinal("TeacherID")) ? reader.GetInt32(reader.GetOrdinal("TeacherID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            Rank = reader["Rank"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });
                    }
                }
            }

            if (teacher == null)
            {
                return NotFound("Teacher not found.");
            }

            return Ok(teacher);
        }

        [HttpGet("Students/{id}")]
        public ActionResult<Student> GetStudent(int id)
        {
            Student student = null;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT StudentID,Role, Name, Email,Password, YearSection FROM Students WHERE StudentID = @StudentID", connection);
                command.Parameters.AddWithValue("@StudentID", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        student = (new Student
                        {
                            StudentID = !reader.IsDBNull(reader.GetOrdinal("StudentID")) ? reader.GetInt32(reader.GetOrdinal("StudentID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            YearSection = reader["YearSection"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });
                    }
                }
            }

            if (student == null)
            {
                return NotFound("Student not found.");
            }

            return Ok(student);
        }

        private string GetExistingPassword(int adminId, MySqlConnection connection)
        {
            var command = new MySqlCommand("SELECT Password FROM Admins WHERE AdminID = @AdminID", connection);
            command.Parameters.AddWithValue("@AdminID", adminId);

            var password = command.ExecuteScalar()?.ToString();
            if (password == null)
            {
                throw new Exception("Admin not found or password is missing.");
            }

            return password;
        }

        // PUT: api/AdminController/Admins/{id}
        [HttpPut("Admins/{id}")]
        public ActionResult UpdateAdmin(int id, [FromBody] Admin updatedAdmin)
        {
            if (updatedAdmin == null || updatedAdmin.AdminID != id)
            {
                return BadRequest("Invalid admin data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Hash the password before updating it
                string hashedPassword = string.IsNullOrWhiteSpace(updatedAdmin.Password)
                    ? GetExistingPassword(id, connection) // Retrieve existing password if not provided
                    : BCrypt.Net.BCrypt.HashPassword(updatedAdmin.Password);

                var command = new MySqlCommand(@"
            UPDATE Admins 
            SET Name = @Name, Email = @Email, Password = @Password, Position = @Position 
            WHERE AdminID = @AdminID", connection);

                command.Parameters.AddWithValue("@Name", updatedAdmin.Name);
                command.Parameters.AddWithValue("@Email", updatedAdmin.Email);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@Position", updatedAdmin.Position);
                command.Parameters.AddWithValue("@AdminID", id);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Admin not found.");
                }
            }

            return NoContent();
        }

        private string GetExistingTeacherPassword(int teacherId, MySqlConnection connection)
        {
            var command = new MySqlCommand("SELECT Password FROM Teachers WHERE TeacherID = @TeacherID", connection);
            command.Parameters.AddWithValue("@TeacherID", teacherId);

            var password = command.ExecuteScalar()?.ToString();
            if (password == null)
            {
                throw new Exception("Teacher not found or password is missing.");
            }

            return password;
        }


        // PUT: api/Teacher/{id}
        [HttpPut("Teachers/{id}")]
        public ActionResult UpdateTeacher(int id, [FromBody] Teacher updatedTeacher)
        {
            if (updatedTeacher == null || updatedTeacher.TeacherID != id)
            {
                return BadRequest("Invalid teacher data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Hash the password before updating it
                string hashedPassword = string.IsNullOrWhiteSpace(updatedTeacher.Password)
                    ? GetExistingTeacherPassword(id, connection) // Retrieve existing password if not provided
                    : BCrypt.Net.BCrypt.HashPassword(updatedTeacher.Password);

                var command = new MySqlCommand(@"
            UPDATE Teachers
            SET Name = @Name, Email = @Email, Password = @Password, Rank = @Rank
            WHERE TeacherID = @TeacherID", connection);

                command.Parameters.AddWithValue("@TeacherID", id);
                command.Parameters.AddWithValue("@Name", updatedTeacher.Name);
                command.Parameters.AddWithValue("@Email", updatedTeacher.Email);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@Rank", updatedTeacher.Rank);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("Teacher not found.");
                }
            }

            return NoContent();
        }

        private string GetExistingStudentPassword(int studentId, MySqlConnection connection)
        {
            var command = new MySqlCommand("SELECT Password FROM Students WHERE StudentID = @StudentID", connection);
            command.Parameters.AddWithValue("@StudentID", studentId);

            var password = command.ExecuteScalar()?.ToString();
            if (password == null)
            {
                throw new Exception("Student not found or password is missing.");
            }

            return password;
        }


        // PUT: api/StudentController/{id}
        [HttpPut("Students/{id}")]
        public ActionResult UpdateStudent(int id, [FromBody] Student updatedStudent)
        {
            if (updatedStudent == null || updatedStudent.StudentID != id)
            {
                return BadRequest("Invalid student data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Hash the password before updating it
                string hashedPassword = string.IsNullOrWhiteSpace(updatedStudent.Password)
                    ? GetExistingStudentPassword(id, connection) // Retrieve existing password if not provided
                    : BCrypt.Net.BCrypt.HashPassword(updatedStudent.Password);

                var command = new MySqlCommand(@"
            UPDATE Students
            SET Name = @Name, Email = @Email, Password = @Password, YearSection = @YearSection
            WHERE StudentID = @StudentID", connection);

                command.Parameters.AddWithValue("@StudentID", id);
                command.Parameters.AddWithValue("@Name", updatedStudent.Name);
                command.Parameters.AddWithValue("@Email", updatedStudent.Email);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@YearSection", updatedStudent.YearSection);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("Student not found.");
                }
            }

            return NoContent();
        }


        // DELETE: api/AdminController/Admins/{id}
        [HttpDelete("Admins/{id}")]
        public ActionResult DeleteAdmin(int id)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("DELETE FROM Admins WHERE AdminID = @AdminID", connection);
                command.Parameters.AddWithValue("@AdminID", id);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Admin not found.");
                }
            }

            return NoContent();
        }

        [HttpDelete("Teachers/{id}")]
        public ActionResult DeleteTeacher(int id)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("DELETE FROM Teachers WHERE TeacherID = @TeacherID", connection);
                command.Parameters.AddWithValue("@TeacherID", id);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Teacher not found.");
                }
            }

            return NoContent();
        }

        [HttpDelete("Students/{id}")]
        public ActionResult DeleteStudent(int id)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("DELETE FROM Students WHERE StudentID = @StudentID", connection);
                command.Parameters.AddWithValue("@StudnetID", id);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Student not found.");
                }
            }

            return NoContent();
        }

        // Example for Courses
        [HttpGet("Courses")]
        public ActionResult<IEnumerable<object>> GetCourses()
        {
            var courses = new List<object>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                var command = new MySqlCommand(@"
            SELECT 
                CourseID, 
                CourseName 
            FROM Courses", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        courses.Add(new
                        {
                            CourseID = reader["CourseID"],
                            CourseName = reader["CourseName"]
                            
                        });
                    }
                }
            }

            if (courses.Count == 0)
            {
                return NotFound("No courses found.");
            }

            return Ok(courses);
        }


        [HttpGet("Courses/{id}")]
        public ActionResult<object> GetCourse(int id)
        {
            using var connection = new MySqlConnection(_connectionString);
            connection.Open();

            // Fetch course details
            var courseQuery = "SELECT CourseID, CourseName FROM Courses WHERE CourseID = @CourseID";
            using var courseCommand = new MySqlCommand(courseQuery, connection);
            courseCommand.Parameters.AddWithValue("@CourseID", id);

            using var courseReader = courseCommand.ExecuteReader();
            if (!courseReader.Read())
            {
                return NotFound("Course not found.");
            }

            var course = new
            {
                CourseID = courseReader["CourseID"],
                CourseName = courseReader["CourseName"]
            };
            courseReader.Close();

           
            return Ok(course);
        }


        [HttpPost("Courses")]
public ActionResult<List<object>> AddCourses([FromBody] List<Course> newCourses)
{
    if (newCourses == null || !newCourses.Any())
    {
        return BadRequest("No courses to add.");
    }

    using var connection = new MySqlConnection(_connectionString);
    connection.Open();

    var addedCourses = new List<object>();
    foreach (var course in newCourses)
    {
        if (string.IsNullOrWhiteSpace(course.CourseName))
        {
            return BadRequest("Course name cannot be null or empty.");
        }

        // Insert course into the database
        var query = "INSERT INTO Courses (CourseID, CourseName) VALUES (@CourseID, @CourseName)";
        using var command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@CourseID", course.CourseID);
        command.Parameters.AddWithValue("@CourseName", course.CourseName);
        

        try
        {
            command.ExecuteNonQuery();
            addedCourses.Add(new { CourseID = course.CourseID, CourseName = course.CourseName , Semester = course.Semester, YearSection = course.YearSection});
        }
        catch (MySqlException ex)
        {
            return BadRequest($"Error adding course: {ex.Message}");
        }
    }

    return Ok(addedCourses);
}
        [HttpPut("Courses/{id}")]
        public ActionResult PutCourse(int id, [FromBody] Course updatedCourse)
        {
            if (updatedCourse == null || updatedCourse.CourseID != id)
            {
                return BadRequest("Invalid course data.");
            }

            if (string.IsNullOrWhiteSpace(updatedCourse.CourseName))
            {
                return BadRequest("Course name cannot be null or empty.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("UPDATE Courses SET CourseName = @CourseName WHERE CourseID = @CourseID", connection);
                command.Parameters.AddWithValue("@CourseName", updatedCourse.CourseName);
                
                command.Parameters.AddWithValue("@CourseID", id);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Course not found.");
                }
            }

            return Ok($"Course name updated to '{updatedCourse.CourseName}' successfully.");
        }

        [HttpDelete("Courses/{id}")]
        public ActionResult DeleteCourse(int id)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Delete related course assignments
                var deleteAssignments = new MySqlCommand("DELETE FROM CourseAssignments WHERE CourseID = @CourseID", connection);
                deleteAssignments.Parameters.AddWithValue("@CourseID", id);
                deleteAssignments.ExecuteNonQuery();

                // Delete the course
                var deleteCourse = new MySqlCommand("DELETE FROM Courses WHERE CourseID = @CourseID", connection);
                deleteCourse.Parameters.AddWithValue("@CourseID", id);
                var rowsAffected = deleteCourse.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("Course not found.");
                }
            }

            return NoContent(); // Successfully deleted
        }

        [HttpGet("GetAllCourseAssignments")]
        public ActionResult<IEnumerable<object>> GetAllCourseAssignments()
        {
            var assignments = new List<object>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
            SELECT 
                ca.AssignmentID, 
                c.CourseID, 
                c.CourseName, 
                ca.TeacherID, 
                t.Name AS TeacherName, 
                ca.StudentID, 
                s.Name AS StudentName, 
                ca.Semester, 
                ca.YearSection
            FROM 
                CourseAssignments ca
            JOIN Courses c ON ca.CourseID = c.CourseID
            JOIN Teachers t ON ca.TeacherID = t.TeacherID
            JOIN Students s ON ca.StudentID = s.StudentID", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        assignments.Add(new
                        {
                            AssignmentID = reader["AssignmentID"],
                            CourseID = reader["CourseID"],
                            CourseName = reader["CourseName"],
                            TeacherID = reader["TeacherID"],
                            TeacherName = reader["TeacherName"],
                            StudentID = reader["StudentID"],
                            StudentName = reader["StudentName"],
                            Semester = reader["Semester"],
                            YearSection = reader["YearSection"]
                        });
                    }
                }
            }

            if (!assignments.Any())
            {
                return NotFound("No course assignments found.");
            }

            return Ok(assignments);
        }

        
        // Add course assignment to a student
        [HttpPost("AssignCourseToStudent")]
        public ActionResult AssignCourseToStudent(int studentId, int courseId, int teacherId, string semester, string yearSection)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                var command = new MySqlCommand(@"
            INSERT INTO CourseAssignments (CourseID, TeacherID, Semester, YearSection, StudentID)
            VALUES (@CourseID, @TeacherID, @Semester, @YearSection, @StudentID)
            ON DUPLICATE KEY UPDATE 
                YearSection = VALUES(YearSection), 
                Semester = VALUES(Semester)", connection);

                command.Parameters.AddWithValue("@CourseID", courseId);
                command.Parameters.AddWithValue("@TeacherID", teacherId);
                command.Parameters.AddWithValue("@Semester", semester);
                command.Parameters.AddWithValue("@YearSection", yearSection);
                command.Parameters.AddWithValue("@StudentID", studentId);

                command.ExecuteNonQuery();
            }

            return Ok("Course assigned to student successfully.");
        }

        // Update an existing course assignment for a student
        [HttpPut("UpdateStudentCourseAssignment")]
        public ActionResult UpdateStudentCourseAssignment(int studentId, int courseId, int teacherId, string newSemester)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Check if the assignment exists for this student, course, and teacher
                var checkCommand = new MySqlCommand(@"
            SELECT COUNT(*) 
            FROM CourseAssignments 
            WHERE StudentID = @StudentID AND CourseID = @CourseID AND TeacherID = @TeacherID", connection);

                checkCommand.Parameters.AddWithValue("@StudentID", studentId);
                checkCommand.Parameters.AddWithValue("@CourseID", courseId);
                checkCommand.Parameters.AddWithValue("@TeacherID", teacherId);

                var assignmentExists = Convert.ToInt32(checkCommand.ExecuteScalar()) > 0;
                if (!assignmentExists)
                {
                    return NotFound("Assignment not found for this student.");
                }

                // Update the semester for the assignment
                var updateCommand = new MySqlCommand(@"
            UPDATE CourseAssignments 
            SET Semester = @NewSemester 
            WHERE StudentID = @StudentID AND CourseID = @CourseID AND TeacherID = @TeacherID", connection);

                updateCommand.Parameters.AddWithValue("@NewSemester", newSemester);
                updateCommand.Parameters.AddWithValue("@StudentID", studentId);
                updateCommand.Parameters.AddWithValue("@CourseID", courseId);
                updateCommand.Parameters.AddWithValue("@TeacherID", teacherId);

                updateCommand.ExecuteNonQuery();
            }

            return Ok("Course assignment updated successfully.");
        }

        // Remove a student from a course assignment
        [HttpDelete("RemoveStudentFromCourse/{courseId}")]
        public ActionResult RemoveStudentFromCourse(int courseId, int studentId)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                var command = new MySqlCommand(@"
            DELETE FROM CourseAssignments 
            WHERE CourseID = @CourseID AND StudentID = @StudentID", connection);

                command.Parameters.AddWithValue("@CourseID", courseId);
                command.Parameters.AddWithValue("@StudentID", studentId);

                var rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    return NotFound("Student or course not found.");
                }
            }

            return Ok("Student removed from course successfully.");
        }

             
    }
}