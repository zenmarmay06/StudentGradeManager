﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using StudentGradeManager.Models;
using StudentGradeManager.Utility;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentGradeManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly string _connectionString;
        private string _jwtKey;

        public StudentController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _jwtKey = configuration["Jwt:Secretkey"];
        }

        // GET: api/StudentController/Students/{id}
        [HttpGet("Students/{id}")]
        public ActionResult<Student> GetStudent(int id)
        {
            Student student = null;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT StudentID, Role,Name, Email, Password,YearSection FROM Students WHERE StudentID = @StudentID", connection);
                command.Parameters.AddWithValue("@StudentID", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        student=(new Student
                        {
                            StudentID = !reader.IsDBNull(reader.GetOrdinal("StudentID")) ? reader.GetInt32(reader.GetOrdinal("StudentID")) : 0, // Default to 0 if NULL
                            Role = reader["Role"] as string ?? "Unknown", // Default to "Unknown" if NULL
                            Name = reader["Name"] as string ?? "No Name", // Default to "No Name" if NULL
                            Email = reader["Email"] as string ?? string.Empty, // Default to empty string if NULL
                            Password = reader["Password"] as string ?? string.Empty, // Default to empty string if NULL
                            YearSection = reader["YearSection"] as string ?? "Unassigned" // Default to "Unassigned" if NULL
                        });
                    }
                }
            }

            if (student == null)
            {
                return NotFound("Student not found.");
            }

            return Ok(student);
        }

        private string GetExistingStudentPassword(int studentId, MySqlConnection connection)
        {
            var command = new MySqlCommand("SELECT Password FROM Students WHERE StudentID = @StudentID", connection);
            command.Parameters.AddWithValue("@StudentID", studentId);

            var password = command.ExecuteScalar()?.ToString();
            if (password == null)
            {
                throw new Exception("Student not found or password is missing.");
            }

            return password;
        }


        // PUT: api/StudentController/{id}
        [HttpPut("{id}")]
        public ActionResult UpdateStudent(int id, [FromBody] Student updatedStudent)
        {
            if (updatedStudent == null || updatedStudent.StudentID != id)
            {
                return BadRequest("Invalid student data.");
            }

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Hash the password before updating it
                string hashedPassword = string.IsNullOrWhiteSpace(updatedStudent.Password)
                    ? GetExistingStudentPassword(id, connection) // Retrieve existing password if not provided
                    : BCrypt.Net.BCrypt.HashPassword(updatedStudent.Password);

                var command = new MySqlCommand(@"
            UPDATE Students
            SET Name = @Name, Email = @Email, Password = @Password, YearSection = @YearSection
            WHERE StudentID = @StudentID", connection);

                command.Parameters.AddWithValue("@StudentID", id);
                command.Parameters.AddWithValue("@Name", updatedStudent.Name);
                command.Parameters.AddWithValue("@Email", updatedStudent.Email);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@YearSection", updatedStudent.YearSection);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    return NotFound("Student not found.");
                }
            }

            return NoContent();
        }

        // GET: api/StudentController/{id}/AssignedCourses
        [HttpGet("{id}/AssignedCourses")]
        public ActionResult<IEnumerable<object>> ViewAssignedCourses(int id)
        {
            var assignedCourses = new List<object>();

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // SQL query updated to correctly select the Semester field from CourseAssignments
                var query = @"
            SELECT 
                ca.CourseID, 
                c.CourseName, 
                ca.Semester, 
                t.Name AS TeacherName
            FROM CourseAssignments ca
            JOIN Courses c ON ca.CourseID = c.CourseID
            LEFT JOIN Teachers t ON ca.TeacherID = t.TeacherID
            WHERE ca.StudentID = @StudentID";  // Fix the condition to match StudentID with ca.StudentID

                var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentID", id);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        assignedCourses.Add(new
                        {
                            CourseID = reader.GetInt32("CourseID"),
                            CourseName = reader.GetString("CourseName"),
                            Semester = reader.GetString("Semester"),
                            Teacher = reader["TeacherName"]?.ToString() ?? "Teacher Not Assigned"
                        });
                    }
                }
            }

            if (!assignedCourses.Any())
            {
                return NotFound("No assigned courses found for the student.");
            }

            return Ok(assignedCourses);
        }


        // GET: api/StudentController/{id}/PerformanceReport
        [HttpGet("{studentId}/PerformanceReport")]
        public ActionResult<object> ViewPerformanceReportByStudent(int studentId, [FromQuery] string semester)
        {
            if (!ValidationUtils.IsValidSemester(semester))
            {
                return BadRequest("Invalid semester. Please specify 'first' or 'second'.");
            }

            var grades = new List<object>();
            string studentName;

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                // Get student details
                var studentQuery = "SELECT Name FROM Students WHERE StudentID = @StudentID";
                var studentCommand = new MySqlCommand(studentQuery, connection);
                studentCommand.Parameters.AddWithValue("@StudentID", studentId);
                studentName = studentCommand.ExecuteScalar()?.ToString();
                if (studentName == null)
                {
                    return NotFound("Student not found.");
                }

                // Get grades
                var gradeQuery = @"SELECT sg.CourseID, sg.TeacherID, sg.MidtermGrade, sg.FinalGrade, c.CourseName
                           FROM grades sg
                           JOIN courses c ON sg.CourseID = c.CourseID
                           JOIN teachers t ON sg.TeacherID = t.TeacherID
                           WHERE sg.StudentID = @StudentID AND sg.Semester = @Semester;";
                var gradeCommand = new MySqlCommand(gradeQuery, connection);
                gradeCommand.Parameters.AddWithValue("@StudentID", studentId);
                gradeCommand.Parameters.AddWithValue("@Semester", semester);

                using (var reader = gradeCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var midterm = reader.GetDouble("MidtermGrade");
                        var final = reader.GetDouble("FinalGrade");
                        grades.Add(new
                        {
                            CourseID = reader.GetInt32("CourseID"),
                            CourseName = reader.GetString("CourseName"),
                            MidtermGrade = midterm,
                            FinalGrade = final,
                            FinalAverage = GradeCalculation.CalculateFinalAverage(midterm, final)
                        });
                    }
                }
            }

            if (!grades.Any())
            {
                return NotFound("No performance data found for this student in the specified semester.");
            }

            var report = new
            {
                StudentName = studentName,
                StudentID = studentId,
                Semester = semester, // Include semester in the report
                Grades = grades
            };

            return Ok(report);
        }

    }
}
