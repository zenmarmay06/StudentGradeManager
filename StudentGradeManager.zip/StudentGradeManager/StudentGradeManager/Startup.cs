using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using System;

namespace StudentGradeManager
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // This method is used to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Get Jwt settings from configuration
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var secretKey = _configuration["Jwt:SecretKey"];

            // Check for missing configuration values
            if (string.IsNullOrEmpty(issuer))
            {
                throw new ArgumentNullException(nameof(issuer), "Issuer cannot be null or empty.");
            }

            if (string.IsNullOrEmpty(audience))
            {
                throw new ArgumentNullException(nameof(audience), "Audience cannot be null or empty.");
            }

            if (string.IsNullOrEmpty(secretKey))
            {
                throw new ArgumentNullException(nameof(secretKey), "SecretKey cannot be null or empty.");
            }

            // JWT Authentication setup
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = issuer,
                    ValidAudience = audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey))
                };

                // Optional: Handle token validation failure responses
                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        // Log the error or perform any actions needed
                        return Task.CompletedTask;
                    },
                    OnChallenge = context =>
                    {
                        // Customize the challenge response for missing or invalid JWT
                        return Task.CompletedTask;
                    }
                };
            });

            // Add controllers and other necessary services
            services.AddControllers();

            // Add Swagger configuration
            services.AddSwaggerGen(options =>
            {
                // Add Bearer token authorization for Swagger UI
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "Enter 'Bearer' followed by your JWT token"
                });

                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] { }
                    }
                });

                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "StudentGradeManager",
                    Version = "v1"
                });
            });
        }

        // This method is used to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "StudentGradeManager API V1");
                });
            }

            app.UseHttpsRedirection();

            // Routing should come before authentication and authorization
            app.UseRouting();

            // Add authentication middleware
            app.UseAuthentication(); // Authentication comes before authorization

            // Add authorization middleware
            app.UseAuthorization(); // Authorization middleware comes after authentication

            // Configure the endpoints for controllers
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers(); // Ensures your controller actions are properly mapped
            });
        }
    }
}
