﻿
    using System.ComponentModel.DataAnnotations;

    namespace StudentGradeManager.Models
    {
        public class Teacher:Person
        {
            public int TeacherID { get; set; }
        //public string Rank { get; set; }
       
        public string Rank { get; set; }
       


    }
    }


