﻿
   using System.ComponentModel.DataAnnotations;

    namespace StudentGradeManager.Models
    {
        public class Admin:Person
        {
            public int AdminID { get; set; }
        // public string Position { get; set; }
        public string Position { get;  set; }
        

    }
    }


