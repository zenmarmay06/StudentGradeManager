﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using StudentGradeManager.Models;
using System.Collections.Generic;
using System.Linq;
namespace StudentGradeManager.Models
{
    public class Student:Person
    {
        public int StudentID { get; set; }


        
        public string YearSection { get; set; }
    }
}

