﻿namespace StudentGradeManager.Model.DTO
{
    public class LoginDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; } // Admin, Teacher, Student
    }
}
